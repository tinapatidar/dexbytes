let admin, name; // can declare two variables at once

name = "John";

admin = name;

console.log( admin ); 